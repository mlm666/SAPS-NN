 # -*- coding: utf-8 -*-
"""
Created on Wed Sep 16 22:05:07 2020

@author: Administrator
"""

# -*- coding: utf-8 -*-

import tensorflow as tf
import numpy as np


def conv_1_1(inputs,n,name, padding = 'same'):
    out = tf.layers.conv2d(inputs, n, 1, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name+'_1_conv', use_bias=False)
    out = tf.nn.relu(out)     
    return out

def conv_1_2(inputs,n,name, padding = 'same'):
    out = tf.layers.conv2d(inputs, n, 1, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name+'_2_conv', use_bias=False)
    out = tf.nn.relu(out)     
    return out




def patt(inputs, N, name, padding = 'same'):
    print(np.shape(inputs))
    n = int(N/4)
    [c,w,h,x] = np.shape(inputs)
    gama = tf.Variable(0.0001,trainable=True,name=name+'gama')
    k_in = conv_1_1(inputs,n,name=name)
    q_in = conv_1_2(inputs,n,name=name)
    v_in = tf.layers.conv2d(inputs, N, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name, use_bias=False) 
    v_in = tf.nn.relu(v_in)
    M = w*h
    print(np.shape(k_in))
    print(k_in)

    k_ = tf.reshape(k_in,[8,M,n])
    q_ = tf.reshape(q_in,[8,M,n])     
    pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
    v_ = tf.reshape(v_in,[8,M,x])  
    att = tf.nn.softmax(tf.matmul(pcm, v_))
    att = tf.reshape(att,[c,w,h,x])
    out = gama*att + inputs
    return out

#
#def patt_all(inputs, N, name, padding = 'same'):
#    print(np.shape(inputs))
#    n = int(N/4)
#    [c,w,h,x] = np.shape(inputs)
#    gama = tf.Variable(0.1,dtype=tf.float32)
#    k_in = conv_1_1(inputs,n,name=name)
#    q_in = conv_1_2(inputs,n,name=name)
#    v_in = tf.layers.conv2d(inputs, N, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name, use_bias=False) 
#    v_in = tf.nn.relu(v_in)
#    M = w*h
#    print(np.shape(k_in))
#    print(k_in)
#
#    k_ = tf.reshape(k_in,[1,M,n])
#    q_ = tf.reshape(q_in,[1,M,n])     
#    pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
#    v_ = tf.reshape(v_in,[1,M,x])  
#    att = tf.nn.softmax(tf.matmul(pcm, v_))
#    att = tf.reshape(att,[c,w,h,x])
#    out = gama*att + inputs
#    return out


def redcnn(input, padding = 'same'):
    
        """
        encoder
        """
        #conv layer1
        conv1 = tf.layers.conv2d(input, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False)
        conv1 = tf.nn.relu(conv1)
    
        #卷积层2————联结8
        conv2 = tf.layers.conv2d(input, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2', use_bias=False)
        conv2 = tf.nn.relu(conv2)
    
        #卷积层3
        conv3 = tf.layers.conv2d(conv2, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        conv3 = tf.nn.relu(conv3)
    
        #卷积层4-------联结6
        conv4 = tf.layers.conv2d(input, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4', use_bias=False)
        conv4 = tf.nn.relu(conv4)
    
        #卷积层5
        conv5 = tf.layers.conv2d(conv4, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
        conv5 = tf.nn.relu(conv5)
    
        #---------------------------解码——————
    
        #反卷积6+联结4
        deconv6 = tf.layers.conv2d_transpose(conv5, 96, 5,padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv6', use_bias=False)
        deconv6 = deconv6 + conv4
        deconv6 = tf.nn.relu(deconv6)
    
        #反卷积7
        deconv7 = tf.layers.conv2d_transpose(deconv6, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv7', use_bias=False)
        deconv7 = tf.nn.relu(deconv7)
    
        #反卷积8+联结2
        deconv8 = tf.layers.conv2d_transpose(deconv7, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv8', use_bias=False)
        deconv8 = deconv8 + conv2
        deconv8 = tf.nn.relu(deconv8)
    
        #反卷积9
        deconv9 = tf.layers.conv2d_transpose(deconv8,  96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv9', use_bias=False)
        deconv9 = tf.nn.relu(deconv9)
    
        #反卷积10+联结输入图像
        deconv10 = tf.layers.conv2d_transpose(deconv9, 1, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv10', use_bias=False)
        deconv10 = deconv10 + input
        output = tf.nn.relu(deconv10)
    

        return output

def redcnn_all(input, padding = 'same'):
    
        """
        encoder
        """
        res = []
        res.append(input)
        
        #conv layer1
        conv1 = tf.layers.conv2d(input, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False)
        conv1 = tf.nn.relu(conv1)
    
        #卷积层2————联结8
        conv2 = patt_all(conv1, 96, name='conv2')
        conv2 = tf.nn.relu(conv2)
    
        #卷积层3
        conv3 = tf.layers.conv2d(conv2, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        conv3 = tf.nn.relu(conv3)
    
        #卷积层4-------联结6
        conv4 = patt_all(conv3, 96, name='conv4')
        conv4 = tf.nn.relu(conv4)
    
        #卷积层5
        conv5 = tf.layers.conv2d(conv4, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
        conv5 = tf.nn.relu(conv5)
    
        #---------------------------解码——————
    
        #反卷积6+联结4
        deconv6 = tf.layers.conv2d_transpose(conv5, 96, 5,padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv6', use_bias=False)
        deconv6 = deconv6 + conv4
        deconv6 = tf.nn.relu(deconv6)
    
        #反卷积7
        deconv7 = tf.layers.conv2d_transpose(deconv6, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv7', use_bias=False)
        deconv7 = tf.nn.relu(deconv7)
    
        #反卷积8+联结2
        deconv8 = tf.layers.conv2d_transpose(deconv7, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv8', use_bias=False)
        deconv8 = deconv8 + conv2
        deconv8 = tf.nn.relu(deconv8)
    
        #反卷积9
        deconv9 = tf.layers.conv2d_transpose(deconv8,  96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv9', use_bias=False)
        deconv9 = tf.nn.relu(deconv9)
    
        #反卷积10+联结输入图像
        deconv10 = tf.layers.conv2d_transpose(deconv9, 1, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv10', use_bias=False)
        deconv10 = deconv10 + input
        output = tf.nn.relu(deconv10)
        
        res.append(output) 

        return res
    

class red():
    def __init__(self, per_path='RED-CNN-SA.npy'):
        self.data_dict = np.load(per_path, encoding='latin1').item()
        print("npy file loaded")

        self.var_dict = {}
#        self.trainable = trainable
#        self.dropout = dropout
        
        
        
    def conv_layer(self, bottom, in_channels, out_channels, name):
        with tf.variable_scope(name):
            filt = self.get_conv_var(5, in_channels, out_channels, name)
    
            conv = tf.nn.conv2d(bottom, filt, [1, 1, 1, 1], padding='SAME')
#            batch_mean, batch_var = tf.nn.moments(conv, [0, 1, 2])
#            bn = tf.nn.batch_normalization(conv, batch_mean, batch_var, 0, 1, 1e-3)
            relu = tf.nn.relu(conv)
            return relu
        
    def deconv_layer(self, bottom, in_channels, out_channels, name):
        
#        [a,b,c,d] = tf.shape(bottom)        
        with tf.variable_scope(name):
            filt = self.get_conv_var(5, in_channels, out_channels, name)
            
            deconv = tf.nn.conv2d_transpose(bottom, filt, strides=[1, 1, 1, 1], output_shape=[1,128,128,in_channels],padding='SAME')            
            return deconv
        



    def att_t(self, bottom, in_channels, out_channels, name):
        n = int(out_channels/4)
        [c,w,h,x] = np.shape(bottom)
        M = w*h
        
#        gama = tf.constant(value, dtype=tf.float32, name=name+'gama')
        value = self.data_dict[name+'gama']

        gama = tf.constant(value, dtype=tf.float32)
        
        filt_1 = self.get_conv_var(1, in_channels, n, name = name+'_1_conv/kernel')
        conv_1 = tf.nn.conv2d(bottom, filt_1, [1, 1, 1, 1], padding='SAME')
        k_in = tf.nn.relu(conv_1)
        
        filt_2 = self.get_conv_var(1, in_channels, n, name = name+'_2_conv/kernel')
        conv_2 = tf.nn.conv2d(bottom, filt_2, [1, 1, 1, 1], padding='SAME')
        q_in = tf.nn.relu(conv_2)
        
        v_in = self.conv_layer(bottom, in_channels, out_channels, name = name+'/kernel')
    
    
    
        k_ = tf.reshape(k_in,[1,M,n])
        q_ = tf.reshape(q_in,[1,M,n]) 
        v_ = tf.reshape(v_in,[1,M,x]) 
        pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
        att = tf.nn.softmax(tf.matmul(pcm, v_))
        att = tf.reshape(att,[c,w,h,x])
        out = gama*att + bottom
        return out
    
    
    
    
    
    
    
    
    
    
    def build(self, img):
        conv1 = self.conv_layer(img, 1, 96, "generator_model/conv1/kernel")
        conv2 = self.att_t(conv1, 96, 96, "generator_model/conv2")
        conv3 = self.conv_layer(conv2, 96, 96, "generator_model/conv3/kernel")
        conv4 = self.att_t(conv3, 96, 96, "generator_model/conv4")
        conv5 = self.conv_layer(conv4, 96, 96, "generator_model/conv5/kernel")
        
        
        deconv6 = self.deconv_layer(conv5, 96, 96, "generator_model/deconv6/kernel")
        deconv6 = deconv6 + conv4
        deconv6 = tf.nn.relu(deconv6)
        
        deconv7 = self.deconv_layer(deconv6, 96, 96, "generator_model/deconv7/kernel")
        deconv7 = tf.nn.relu(deconv7)
        

        deconv8 = self.deconv_layer(deconv7, 96, 96, "generator_model/deconv8/kernel")
        deconv8 = deconv8 + conv2
        deconv8 = tf.nn.relu(deconv8)
        
        deconv9 = self.deconv_layer(deconv8, 96, 96, "generator_model/deconv9/kernel")
        deconv9 = tf.nn.relu(deconv9)
        
        deconv10 = self.deconv_layer(deconv9, 1, 96, "generator_model/deconv10/kernel")
        deconv10 = deconv10 + img
        out = tf.nn.relu(deconv10)

#        self.conv5 = self.conv_layer(self.conv4, 256, 256, "AE/conv5/kernel")
#        self.conv6 = self.conv_layer(self.conv5, 256, 128, "AE/conv6/kernel")
#        
#        self.deconv1 = self.deconv_layer(self.conv6, 128, 128, 'AE/deconv1/kernel')
#
#        self.conv7 = self.conv_layer(self.deconv1, 128, 64, 'AE/conv7/kernel')
#        
#        self.deconv2 = self.deconv_layer(self.conv7, 64, 64, 'AE/deconv2/kernel')       
#        
#        self.conv8 = self.conv_layer(self.deconv2, 64, 32, 'AE/conv8/kernel')
#        
#        self.conv9 = self.output(self.conv8, 32, 1, 'AE/conv9/kernel')
        return out
        
    def max_pool(self, bottom):
        return tf.nn.max_pool(bottom, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
    
    def get_conv_var(self, filter_size, in_channels, out_channels, name):
        initial_value = tf.truncated_normal([filter_size, filter_size, in_channels, out_channels], 0.0, 0.001)
        filters = self.get_var(initial_value, name,name + "_filters")
        return filters

    def get_var(self, initial_value, name, var_name):
#        if self.data_dict is not None and name in self.data_dict:
        value = self.data_dict[name]

        var = tf.constant(value, dtype=tf.float32, name=var_name)

        self.var_dict[(name)] = var

        # print var_name, var.get_shape().as_list()
        assert var.get_shape() == initial_value.get_shape()

        return var




def redcnn_ori(input, padding = 'same'):
    
        """
        encoder
        """
        
        #conv layer1
        conv1 = tf.layers.conv2d(input, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False)
        conv1 = tf.nn.relu(conv1)
    
        #卷积层2————联结8
        conv2 = tf.layers.conv2d(conv1, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2', use_bias=False)
        conv2 = tf.nn.relu(conv2)
    
        #卷积层3
        conv3 = tf.layers.conv2d(conv2, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        conv3 = tf.nn.relu(conv3)
    
        #卷积层4-------联结6
        conv4 = tf.layers.conv2d(conv3, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4', use_bias=False)
        conv4 = tf.nn.relu(conv4)
    
        #卷积层5
        conv5 = tf.layers.conv2d(conv4, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
        conv5 = tf.nn.relu(conv5)
    
        #---------------------------解码——————
    
        #反卷积6+联结4
        deconv6 = tf.layers.conv2d_transpose(conv5, 96, 5,padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv6', use_bias=False)
        deconv6 = deconv6 + conv4
        deconv6 = tf.nn.relu(deconv6)
    
        #反卷积7
        deconv7 = tf.layers.conv2d_transpose(deconv6, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv7', use_bias=False)
        deconv7 = tf.nn.relu(deconv7)
    
        #反卷积8+联结2
        deconv8 = tf.layers.conv2d_transpose(deconv7, 96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv8', use_bias=False)
        deconv8 = deconv8 + conv2
        deconv8 = tf.nn.relu(deconv8)
    
        #反卷积9
        deconv9 = tf.layers.conv2d_transpose(deconv8,  96, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv9', use_bias=False)
        deconv9 = tf.nn.relu(deconv9)
    
        #反卷积10+联结输入图像
        deconv10 = tf.layers.conv2d_transpose(deconv9, 1, 5, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='deconv10', use_bias=False)
        deconv10 = deconv10 + input
        output = tf.nn.relu(deconv10)
        
        return output







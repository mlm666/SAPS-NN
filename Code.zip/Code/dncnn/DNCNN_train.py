# -*- coding: utf-8 -*-
"""
Created on Wed Oct 14 20:40:41 2020

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 16:03:18 2020

@author: Administrator
"""

#!/usr/bin/env python
# coding: utf-8

# In[4]:


#!/usr/bin/env python

import tensorflow as tf
import numpy as np
from DNCNN_model import *
import h5py
import time
import os
import logging
from sklearn.utils import shuffle
import per_loss as PER

tf.reset_default_graph()



#def gaussian_noise(img, mean = 0, sigma = 0.05):
#    '''
#    此函数用将产生的高斯噪声加到图片上
#    传入:
#        img   :  原图
#        mean  :  均值
#        sigma :  标准差
#    返回:
#        gaussian_out : 噪声处理后的图片
#        noise        : 对应的噪声
#    '''
#    # 将图片灰度标准化
#   # img = normalization(img)
#    # 产生高斯 noise
#    noise = np.random.normal(mean, sigma, img.shape)
#    # 将噪声和图片叠加
#    gaussian_out = img + noise
#    # 将超过 1 的置 1，低于 0 的置 0
#    gaussian_out = np.clip(gaussian_out, 0, 1)
#    # 将图片灰度范围的恢复为 0-255
#    #gaussian_out = np.uint8(gaussian_out*255)
#    # 将噪声范围搞为 0-255
#    # noise = np.uint8(noise*255)
#    return gaussian_out # 这里也会返回噪声，注意返回值

os.environ['CUDA_VISIBLE_DEVICES'] = '0'


input_width = 32
input_height = 32

output_width = 32
output_height = 32

batch_size = 32

learning_rate = 1e-4

beta1 = 0.9
beta2 = 0.999 

Num_CLONE = 5
lambda_p = 50
edge_p = 50


num_epoch = 200

Methodname = 'DNCNN'

Networkfolder = Methodname

if not os.path.exists('Mayo_logs'):
	os.mkdir('Mayo_logs')

if not os.path.exists('Networks'):
	os.mkdir('Networks')

logfilename = 'Networks_neu/' + Networkfolder + '.log'

###################################################

##if os.path.exists('Networks/' + Networkfolder):
##	print('Warning!  Network/' + Networkfolder + ' exists!!!!!')
##	raise NameError('Folder exists')

##if os.path.exists(logfilename):
##	print('Warning! Log File has existed!!!!')
##	raise NameError('Log FIle exists!!!')

# Logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s, %(message)s',
                    filename=logfilename,
                    filemode='w')

logging.info('Epoch, batch, time,  gen_cost, is_training')

# generator networks
X = tf.placeholder(dtype=tf.float32, shape=[batch_size, input_width, input_height, 1])
real_data = tf.placeholder(dtype=tf.float32, shape=[batch_size, output_width, output_height, 1])

with tf.variable_scope('DNCNN', reuse=tf.AUTO_REUSE) as scope:
    Y_ = dncnn(X)
    
#with tf.variable_scope('AE', reuse=tf.AUTO_REUSE) as scope:
#    per_loss = perceptual_loss(Y_, real_data)


#perc = PER.per


#yp = perc().build(img=Y_)
#rp = perc().build(img=real_data)
#
#per_loss = tf.reduce_mean(tf.squared_difference(yp, rp))
#
#alpha = tf.random_uniform(shape=[batch_size,1],
#                            minval=0.,
#                            maxval=1.)




#gen_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='generator_model')

gen_params = tf.trainable_variables()
#mse_cost = tf.reduce_mean(tf.squared_difference(Y_, real_data))
Y = real_data - X
mse_cost = (1.0 / batch_size) * tf.nn.l2_loss(Y_ - Y)



#########define PERCEPTUAL LOSS#############

#per = tf.Graph()
#
#sess1 = tf.Session()
#sess1.run(tf.global_variables_initializer())
#model_saver = tf.train.Saver()
#model_saver = tf.train.import_meta_graph('./Networks/perceptual loss/Auto-encoder199.ckpt.meta') 
#model_saver.restore(sess1,'./Networks/perceptual loss/Auto-encoder199.ckpt')



#mse_cost = per_loss(Y_, real_data,batch_size, input_width, input_height)



gen_loss = mse_cost

# optimizer
lr = tf.placeholder(tf.float32, shape=[])

gen_train_op = tf.train.AdamOptimizer(learning_rate=lr).minimize(gen_loss, var_list=gen_params)


# training
sess = tf.Session()

sess.run(tf.global_variables_initializer())


saver = tf.train.Saver(max_to_keep = 3)

#def normalization(x):
##     if region == 'ABD':
##         lower = -160.0
##         upper = 240.0
#    
##    lower = 100
##    upper = 3100 
#
#    x = x / 255
#    x[x<0.0] = 0.0
#    x[x>1.0] = 1.0
#    return np.transpose(x, (0, 1, 2, 3))




print('Loading dataset')
print('Warning: This is a lite dataset for testing code. The model should be sub-optimal!')
f = h5py.File('neu_train_BIG.h5', 'r')
data, label = np.array(f['data']), np.array(f['label'])
f.close()

f = h5py.File('neu_test_BIG.h5', 'r')
test_data, test_label = np.array(f['data']), np.array(f['label'])
f.close()

print("Start training ... ")
for iteration in range(num_epoch):

    val_lr = learning_rate / np.sqrt(iteration + 1)
    data, label = shuffle(data, label)
    num_batches = data.shape[0] // batch_size

    for i in range(num_batches):
        start_time = time.time()


        batch_data = data[i*batch_size : (i+1)*batch_size]
        batch_label = label[i*batch_size : (i+1)*batch_size]

        # generator
#        _gen_loss, _ = sess1.run([gen_loss, gen_train_op],
#                                                        feed_dict={real_data: normalization(batch_label),
#                                                                          X:gaussian_noise(normalization(batch_data)),
#                                                                          lr: val_lr})
#        = sess1.run([],feed_dict={real_data: normalization(batch_label),
#                                                     X:normalization(batch_data)})
        _gen_loss ,_ = sess.run([gen_loss, gen_train_op],feed_dict={real_data: batch_label,
                                                     X:batch_data,lr: val_lr})

        t = time.time() - start_time
        if i%20==0:
            print('Epoch: %d - %d - gen_loss: %.6f'%(
             iteration, i,  _gen_loss ))

        logging.info('%d, %d, %.6f, %.6f, 1'
            %(iteration, i, t,  _gen_loss))




    _gen_loss = 0.0


    start_time = time.time()
    test_num_batch = test_data.shape[0] // batch_size
    for j in range(test_num_batch):
        batch_data = test_data[j*batch_size:(j+1)*batch_size]
        batch_label = test_label[j*batch_size:(j+1)*batch_size]
        t_gen_loss = sess.run(gen_loss,feed_dict={real_data: batch_label,
                                                                   X:batch_data})
        _gen_loss += t_gen_loss


    t = time.time() - start_time
    _gen_loss /= (test_num_batch),

    print('Test....Epoch: %d - %d - gen_loss: %.6f'%(
    iteration, i, _gen_loss ))

    logging.info('%d, %d, %.6f, %.6f, 0'
    %(iteration, i, t,  _gen_loss))
 
    if not os.path.exists('Networks_neu/' + Networkfolder):
        os.mkdir('Networks_neu/' + Networkfolder)
    saver.save(sess, './Networks_neu/'+ Networkfolder +'/DNCNN model' + repr(iteration) + '.ckpt')

sess.close()





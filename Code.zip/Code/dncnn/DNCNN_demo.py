
import tensorflow as tf
import numpy as np
from DNCNN_model import *

from test_rule import *
import pydicom as dicom
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import random
import os
import cv2


#os.environ['CUDA_VISIBLE_DEVICES']='0'




path = 'PETtest/robust/10/' # LDCT image
HD_path = 'PETtest/150npy/' 
#image_name = 'test_images/L506_FD_1_1.CT.0002.0087.2015.12.22.20.19.52.894480.358591878.IMA' # NDCT image
files = os.listdir(HD_path)

input_width = 150
input_height = 150




# generator networks
X = tf.placeholder(dtype=tf.float32, shape=[1, input_width, input_height, 1])

with tf.variable_scope('DNCNN', reuse=tf.AUTO_REUSE) as scope:
#    Y = DD_net_all(X, padding='same') # Y stores all intermediate denoised images and input itself.
    Y_ = dncnn(X)

#################RED-CNN-SA
#cla = RED.red
#
#Y = cla().build(img=X)

##############

Z = tf.placeholder(dtype=tf.float32, shape=[1, input_width, input_height, 1])

Y = X + Y_

mse = tf.reduce_mean(tf.squared_difference(X, Z))
edge = tf.reduce_mean(tf.squared_difference(tf.image.sobel_edges(X), tf.image.sobel_edges(X)))
ssim = tf_ssim(X, Z)

#ms_ssim = tf_ms_ssim(X, Z)

sess = tf.Session()


saver = tf.train.Saver()
saver.restore(sess, './Networks_neu/DNCNN/DNCNN model139.ckpt')

f_mse = 0
f_psnr = 0
f_ssim = 0

o_mse = 0
o_psnr = 0
o_ssim = 0


for p in files:
#READ HD-data
    HD_pixel = np.load(HD_path+"{image}.npy".format(image=p[0:5]))
#    HD_image = plt.imread(HD_path+"{image}".format(image=p))
#    HD_pixel = cv2.cvtColor(HD_image,cv2.COLOR_RGB2GRAY)
#    HD_pixel = HD_pixel[107:235,182:310]
#    HD_pixel = (HD_pixel - 0) / 255  
    	
    HD_pixel[HD_pixel>1.0] = 1.0
    HD_pixel[HD_pixel<0.0] = 0.0
    
    
    HDdata = np.expand_dims(HD_pixel, axis=0)
    HDdata = np.expand_dims(HDdata, axis=3)

#
    
    img_pixel = np.load(path+"{image}.npy".format(image=p[0:5]))
#    img_pixel = img_pixel[64:192,64:192]
    #if region == 'ABD':
    #	img_pixel = (img_pixel - 1024.0 + 160.0) / 400.0 
    #else:
#    img_pixel = (img_pixel -0) / 255
    	
    img_pixel[img_pixel>1.0] = 1.0
    img_pixel[img_pixel<0.0] = 0.0
    plt_data = []
    
    inputdata = img_pixel
    
    LD_data = inputdata
    plt_data.append(inputdata)
    inputdata = np.expand_dims(inputdata, axis=0)
    inputdata = np.expand_dims(inputdata, axis=3)
    outputdata = sess.run(Y, feed_dict = {X : inputdata})
    outputdata[outputdata>1.0]=1.0
    outputdata[outputdata<0.0]=0.0
    
#    outputdata = np.reshape(outputdata,[128,128])
#    outputdata = np.squeeze(outputdata)
    
    plt_data.append(outputdata)
#    inputdata = img_pixel
#    inputdata = np.expand_dims(inputdata, axis=3)
#    outputdata = sess.run(Y, feed_dict = {X : inputdata})
#    inputdata = np.expand_dims(inputdata, axis=0)
    

#    for img in outputdata:
#        img[img > 1.0] = 1.0
#        img[img < 0.0] = 0.0
#        img = np.squeeze(img)
#        plt_data.append(img)
    plt_data.append(HD_pixel)
    
    ORI = plt_data[0]
    ORI = np.expand_dims(ORI, axis=0)   
    ORI = np.expand_dims(ORI, axis=3)
    
    NN = plt_data[1]
#    NN = np.expand_dims(NN, axis=3)
#    NN = np.expand_dims(NN, axis=0)
    
    mse_ = sess.run(mse, feed_dict = {X : ORI, Z : HDdata})
#    edge_loss = sess.run(edge, feed_dict = {X : NN, Z : HDdata})
    ssim_ = sess.run(ssim, feed_dict = {X : ORI, Z : HDdata})
    psnr_ = psnr(ORI, HDdata)    
    
    mse_loss = sess.run(mse, feed_dict = {X : NN, Z : HDdata})
#    edge_loss = sess.run(edge, feed_dict = {X : NN, Z : HDdata})
    ssim_loss = sess.run(ssim, feed_dict = {X : NN, Z : HDdata})
    psnr_loss = psnr(NN, HDdata)
    
    ms_ssim_loss = sess.run(tf_ms_ssim(NN, HDdata))
#    ms_ssim_loss = sess.run(ms_ssim, feed_dict = {X : NN, Z : HDdata})
    
    f_mse = f_mse + mse_loss
    f_psnr = f_psnr + psnr_loss
    f_ssim = f_ssim + ssim_loss
    
    o_mse = o_mse + mse_
    o_psnr = o_psnr + psnr_
    o_ssim = o_ssim + ssim_
    
    
    for i in range(3):
        plt_data[i] = np.squeeze(plt_data[i])
    
    print('test_number: %s - mse:%.6f - ssim:%.6f - psnr:%.6f - mssim:%.6f'%
                                  (p,mse_loss  ,ssim_loss,psnr_loss, ms_ssim_loss))
    with open("result.txt","a")as t:
        t.write("before the net --- test_number: %s - mse:%.6f - ssim:%.6f - psnr:%.6f\n"%(p,mse_  , ssim_, psnr_))
        t.write("result --- test_number: %s - mse:%.6f - ssim:%.6f - psnr:%.6f\n\n"%(p,mse_loss , ssim_loss, psnr_loss))
    
    fig_titles = ['LDPET', 'DNCNN', 'HDPET']
    plt.figure()
#    f, axs = plt.subplots(figsize=(40, 40), nrows=1, ncols=7)
    f, axs = plt.subplots(figsize=(60, 60),nrows=1, ncols=3)
    
    for i, img in enumerate(plt_data):
        axs[i].imshow(img, cmap=plt.cm.gray)
        axs[i].set_title(fig_titles[i], fontsize=30)
        axs[i].axis('off')
    plt.savefig('./result_neu/DNCNN/DNCNN{name}.pdf'.format(name=p[0:5]), bbox_inches = 'tight', pad_inches=0.1)
    np.save('./result_neu/DNCNN/npy/{name}.npy'.format(name=p[0:5]),plt_data[1])

f_mse = f_mse / 147
f_psnr = f_psnr / 147
f_ssim = f_ssim / 147

o_mse = o_mse / 147
o_psnr = o_psnr / 147
o_ssim = o_ssim / 147

with open("result.txt","a")as t:
    t.write("average --- before the net ---  mse:%.6f - ssim:%.6f - psnr:%.6f\n"%(o_mse, o_ssim, o_psnr))
    t.write("result ---  mse:%.6f - ssim:%.6f - psnr:%.6f\n\n"%(f_mse, f_ssim, f_psnr))
    

t.close
sess.close()
       
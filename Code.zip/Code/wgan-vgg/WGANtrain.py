# -*- coding: utf-8 -*-
"""
Created on Wed May  5 15:32:32 2021

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 16:03:18 2020

@author: Administrator
"""

#!/usr/bin/env python
# coding: utf-8

# In[4]:


#!/usr/bin/env python

import tensorflow as tf
import numpy as np
#from models import *
from WGANmodel import *
#from map_change import *
import h5py
import time
import os
import logging
from sklearn.utils import shuffle

tf.reset_default_graph()



#def gaussian_noise(x):
#    '''
#    此函数用将产生的高斯噪声加到图片上
#    传入:
#        img   :  原图
#        mean  :  均值
#        sigma :  标准差
#    返回:
#        gaussian_out : 噪声处理后的图片
#        noise        : 对应的噪声
#    '''
#    # 将图片灰度标准化
#   # img = normalization(img)
#    # 产生高斯 noise
#    s = np.random.normal(x, x/5)
#    # 将超过 1 的置 1，低于 0 的置 0
#    gaussian_out = np.clip(s, 0, 1)
#    # 将图片灰度范围的恢复为 0-255
#    #gaussian_out = np.uint8(gaussian_out*255)
#    # 将噪声范围搞为 0-255
#    # noise = np.uint8(noise*255)
#    return gaussian_out # 这里也会返回噪声，注意返回值

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

vgg =Vgg19() 

input_width = 32 
input_height = 32

output_width = 32
output_height = 32 

batch_size = 32

learning_rate = 1e-5

beta1 = 0.5
beta2 = 0.9 




num_epoch = 200
disc_iters = 4  

Methodname = 'WGAN'

Networkfolder = Methodname

if not os.path.exists('Mayo_logs'):
	os.mkdir('Mayo_logs')

if not os.path.exists('Networks'):
	os.mkdir('Networks')

logfilename = 'Networks_neu/' + Networkfolder + '.log'



#if os.path.exists('Networks/' + Networkfolder):
#	print('Warning!  Network/' + Networkfolder + ' exists!!!!!')
#	raise NameError('Folder exists')
# 
#if os.path.exists(logfilename):
#	print('Warning! Log File has existed!!!!')
#	raise NameError('Log FIle exists!!!')

# Logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s, %(message)s',
                    filename=logfilename,
                    filemode='w')

logging.info('Epoch, batch, time, disc_loss, difference, mse_cost, gen_loss, gen_cost, is_training')

# generator networks
X = tf.placeholder(dtype=tf.float32, shape=[batch_size, input_width, input_height, 1])

#with tf.variable_scope('generator_model', reuse=tf.AUTO_REUSE) as scope:
#    Y_ =generator(X)
Y_ = generator(X, reuse = False)

real_data = tf.placeholder(dtype=tf.float32, shape=[batch_size, output_width, output_height, 1])

alpha = tf.random_uniform(shape=[batch_size,1],
                            minval=0.,
                            maxval=1.)

# discriminator networks
#with tf.variable_scope('discriminator_model') as scope:
disc_real = discriminator(real_data, reuse = False)
#scope.reuse_variables()
disc_fake = discriminator(Y_)
interpolates = alpha*tf.reshape(real_data, [batch_size, -1]) + (1-alpha)*tf.reshape(Y_, [batch_size, -1])
interpolates = tf.reshape(interpolates, [batch_size, output_width, output_height, 1])
gradients = tf.gradients(discriminator(interpolates), [interpolates])[0]

# generator loss
gen_cost = -tf.reduce_mean(disc_fake)

# discriminator loss
difference = tf.reduce_mean(disc_fake) - tf.reduce_mean(disc_real)

# gradient penalty
slopes = tf.sqrt(tf.reduce_sum(tf.square(gradients), axis=1))
gradient_penalty = tf.reduce_mean((slopes-1.)**2)

# Final disc objective function
disc_loss = difference + 10 * gradient_penalty   # add gradient constraint to discriminator loss

#gen_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='generator_model')
#disc_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='discriminator_model')

t_vars = tf.trainable_variables()
gen_params = [var for var in t_vars if 'generator' in var.name]
disc_params = [var for var in t_vars if 'discriminator' in var.name]


mse_cost = tf.reduce_mean(tf.squared_difference(Y_, real_data))


###################################################per loss

#perceptual loss
Y_3c = tf.concat([Y_]*3, axis=3)
real_data_3c = tf.concat([real_data]*3, axis=3)
[w, h, d] = Y_3c.get_shape().as_list()[1:]
vgg_perc_loss = tf.reduce_mean(tf.sqrt(tf.reduce_sum(tf.square((vgg.extract_feature(Y_3c) -  vgg.extract_feature(real_data_3c))))) / (w*h*d))

        #discriminator loss(WGAN LOSS)





edge_cost = tf.reduce_mean(tf.squared_difference(tf.image.sobel_edges(Y_), tf.image.sobel_edges(real_data)))

gen_loss = gen_cost + 0.1 * vgg_perc_loss 
#gen_loss = gen_cost +  lambda_p * mse_cost + edge_p * edge_cost

# optimizer
lr = tf.placeholder(tf.float32, shape=[])
gen_train_op = tf.train.AdamOptimizer(learning_rate=lr,
                                        beta1=beta1,
                                        beta2=beta2).minimize(gen_loss, var_list=gen_params)

disc_train_op = tf.train.AdamOptimizer(learning_rate=lr,
                                        beta1=beta1,
                                        beta2=beta2).minimize(disc_loss, var_list=disc_params)



# training
sess = tf.Session()

sess.run(tf.global_variables_initializer())


saver = tf.train.Saver(max_to_keep = 3)

#def normalization(x):
##     if region == 'ABD':
##         lower = -160.0
##         upper = 240.0
#    
#    lower = 0
#    upper = 255
#
#    x = (x - lower) / (upper - lower)
#    x[x<0.0] = 0.0
#    x[x>1.0] = 1.0
#    return np.transpose(x, (0, 1, 2, 3))




print('Loading dataset')
print('Warning: This is a lite dataset for testing code. The model should be sub-optimal!')
f = h5py.File('neu_train.h5', 'r')
data, label = np.array(f['data']), np.array(f['label'])
f.close()

f = h5py.File('neu_test.h5', 'r')
test_data, test_label = np.array(f['data']), np.array(f['label'])
f.close()

print("Start training ... ")
for iteration in range(num_epoch):

    val_lr = learning_rate / np.sqrt(iteration + 1)
    data, label = shuffle(data, label)
    num_batches = data.shape[0] // batch_size

    for i in range(num_batches):
        start_time = time.time()
        # discriminator
        for j in range(disc_iters):
            idx = np.random.permutation(data.shape[0])
            batch_data = data[idx[:batch_size]]
            batch_label = label[idx[:batch_size]]
            sess.run([disc_train_op], feed_dict={real_data: batch_label,
                                                         X:batch_data,
                                                        lr: val_lr})

        batch_data = data[i*batch_size : (i+1)*batch_size]
        batch_label = label[i*batch_size : (i+1)*batch_size]
        
        #################
#        yp = perc().build(img=normalization(batch_data))
#        rp = perc().build(img=normalization(batch_label))
#        
#        per_cost = tf.reduce_mean(tf.squared_difference(yp, rp))
###########################
        
        # generator
        
        
        _disc_loss, _difference, _mse_cost, _gen_loss, _gen_cost, _ = sess.run([disc_loss, difference,  mse_cost,
                                                         gen_loss, gen_cost, gen_train_op],
                                                        feed_dict={real_data: batch_label,
                                                                          X:batch_data,
                                                                          lr: val_lr})

        t = time.time() - start_time
        if i%40==0:
            print('Epoch: %d - %d - disc_loss: %.6f - gen_loss: %.6f - mse_loss: %.6f'%(
             iteration, i, _disc_loss , _gen_loss  , _mse_cost ))
    
            logging.info('%d, %d, %.6f, %.6f, %.6f, %.6f, %.6f, %.6f, 1'
                %(iteration, i, t, _disc_loss, _difference,  _mse_cost ,  _gen_loss, _gen_cost))


 
    _mse_cost = 0.0
    _disc_loss = 0.0
    _difference = 0.0
    _gen_loss = 0.0
    _gen_cost = 0.0 
    start_time = time.time()
    test_num_batch = test_data.shape[0] // batch_size
    for j in range(test_num_batch):
        batch_data = test_data[j*batch_size:(j+1)*batch_size]
        batch_label = test_label[j*batch_size:(j+1)*batch_size]
        t_disc_loss, t_difference,  t_mse_cost,  t_gen_loss, t_gen_cost = sess.run([disc_loss, difference,  mse_cost,
                                                 gen_loss, gen_cost],
                                                feed_dict={real_data: batch_label,
                                                                   X:batch_data})
        _mse_cost += t_mse_cost
        _disc_loss += t_disc_loss
        _difference += t_difference
        _gen_loss += t_gen_loss
        _gen_cost += t_gen_cost
        
    t = time.time() - start_time
    _mse_cost /= (test_num_batch)
    _disc_loss /= (test_num_batch)
    _difference /= (test_num_batch)
    _gen_loss /= (test_num_batch),
    _gen_cost /= (test_num_batch)
    print('Test....Epoch: %d - %d - disc_loss: %.6f - gen_loss: %.6f  - mse_loss: %.6f'%(
    iteration, i, _disc_loss, _gen_loss, _mse_cost ))

    logging.info('%d, %d, %.6f, %.6f,  %.6f,  %.6f,  %.6f,  %.6f, 0'
    %(iteration, i, t, _disc_loss, _difference,  _mse_cost,  _gen_loss, _gen_cost))

    if not os.path.exists('Networks_neu/' + Networkfolder):
        os.mkdir('Networks_neu/' + Networkfolder)
    saver.save(sess, './Networks_neu/'+ Networkfolder +'/WGAN_' + repr(iteration) + '.ckpt')
writer = tf.summary.FileWriter('./Networks_neu/WGAN/', sess.graph)
writer.close()
sess.close()





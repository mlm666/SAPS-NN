
import tensorflow as tf
import numpy as np


# def conv_1_1(inputs,n,name, padding = 'same'):
# #    conv1 = tf.layers.conv2d(inputs, n, 1, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name+'_1_conv', use_bias=False)
# #    out1 = tf.nn.relu(conv1)   
#     conv2 = tf.layers.conv2d(inputs, n, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name+'_1_conv', use_bias=False)
#     out2 = tf.nn.relu(conv2)     
#     return out2

def conv_1_2(inputs,n,name, padding = 'same'):
    out = tf.layers.conv2d(inputs, n, 1, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name+'_1_conv', use_bias=False)
    out = tf.nn.relu(out)     
    return out




def patt(inputs, N, gama, name, padding = 'same'):


    v_in = tf.layers.conv2d(inputs, N, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name, use_bias=False) 
    v_in = tf.nn.relu(v_in)
    
    [c,w,h,x] = np.shape(v_in)
    

    # q_in = conv_1_2(inputs,n,name=name+'_1')
    # k_in = conv_1_2(inputs,n,name=name+'_2')   
    q_in = v_in
    k_in = q_in
    M = int(w*h)
    print(np.shape(k_in))
    print(M)

    k_ = tf.reshape(k_in,[32,M,x])
    q_ = tf.reshape(q_in,[32,M,x])     
    pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
    pcm = tf.nn.softmax(pcm)
    v_ = tf.reshape(v_in,[32,M,x])  
    att = tf.matmul(pcm, v_)
    att = tf.reshape(att,[c,w,h,x])
    att_out = gama*att + v_in
    out = tf.concat([att_out,v_in],3)
    return out

def patt_t(inputs, N, gama, name, padding = 'same'):
    
    v_in = tf.layers.conv2d(inputs, N, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name, use_bias=False) 
    v_in = tf.nn.relu(v_in)
    
    [c,w,h,x] = np.shape(v_in)
    

    # q_in = conv_1_2(inputs,n,name=name+'_1')
    # k_in = conv_1_2(inputs,n,name=name+'_2')   
    q_in = v_in
    k_in = q_in
    M = int(w*h)
    print(np.shape(k_in))
    print(M)

    k_ = tf.reshape(k_in,[1,M,x])
    q_ = tf.reshape(q_in,[1,M,x])     
    pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
    pcm = tf.nn.softmax(pcm)
    v_ = tf.reshape(v_in,[1,M,x])  
    att = tf.matmul(pcm, v_)
    att = tf.reshape(att,[c,w,h,x])
    att_out = gama*att + v_in
    out = tf.concat([att_out,v_in],3)
    return out





def SA_NN_all(inputs, padding = 'same', D = 4):
    '''
    MAP-NN 

    inputs: N x input_width x input_height x 1
    
    '''
    res = []
    res.append(inputs)
    gama2 = tf.Variable(0.0001,trainable=True, name='conv2_gama')
    gama3 = tf.Variable(0.0001,trainable=True, name='conv3_gama')    
    gama4 = tf.Variable(0.0001,trainable=True, name='conv4_gama')
    
    for _ in range(D):
 
        #inputs = tf.placeholder(dtype=tf.float32, shape=[None, input_width, input_height, 1])
        outputs1 = tf.layers.conv2d(inputs, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False) 
        outputs2 = tf.nn.relu(outputs1)
        
        # outputs2 = tf.layers.conv2d(outputs2, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2', use_bias=False)
        # outputs3 = tf.nn.relu(outputs2) 

  
      
        outputs2 = patt_t(outputs2,32,gama2,name='SA2')
        outputs3 = tf.nn.relu(outputs2)
        
        outputs3 = tf.layers.conv2d(outputs3, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv_3', use_bias=False)
        outputs4 = tf.nn.relu(outputs3) 
        
        
        # outputs4 = tf.layers.conv2d(outputs4, 16, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        # outputs5 = tf.nn.relu(outputs4)
        
        outputs4 = patt_t(outputs4,16,gama3, name='SA3')
        outputs5 = tf.nn.relu(outputs4)
        
        outputs5 = tf.layers.conv2d(outputs5, 16, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        outputs6 = tf.nn.relu(outputs5)
        
        
        
        outputs6 = tf.layers.conv2d(outputs6, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4', use_bias=False)
        outputs7 = tf.nn.relu(outputs6) 

  
      
        outputs7 = patt_t(outputs7,32,gama4,name='SA4')
        outputs8 = tf.nn.relu(outputs7)
        
        outputs8 = tf.layers.conv2d(outputs8, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
        outputs8 = tf.concat([outputs1, outputs8], 3)
        outputs9 = tf.nn.relu(outputs8)
        
        
        outputs9 = tf.layers.conv2d(outputs9, 1, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv6', use_bias=False)
        outputs10 = tf.nn.relu(inputs + outputs9)
        # outputs10 = tf.nn.relu(outputs9)
        # 
        inputs = tf.clip_by_value(outputs10, 0.0, 1.0)
        res.append(inputs)

    return res


def SA_NN(inputs, padding = 'same', D = 4):
    '''
    MAP-NN 

    inputs: N x input_width x input_height x 1
    
    '''
    
    gama2 = tf.Variable(0.0001,trainable=True, name='conv2_gama')
    gama3 = tf.Variable(0.0001,trainable=True, name='conv3_gama')    
    gama4 = tf.Variable(0.0001,trainable=True, name='conv4_gama')
    
    for _ in range(D):
 
        #inputs = tf.placeholder(dtype=tf.float32, shape=[None, input_width, input_height, 1])
        outputs1 = tf.layers.conv2d(inputs, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False) 
        outputs2 = tf.nn.relu(outputs1)
        
        # outputs2 = tf.layers.conv2d(outputs2, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2', use_bias=False)
        # outputs3 = tf.nn.relu(outputs2) 

  
      
        outputs2 = patt(outputs2,32,gama2,name='SA2')
        outputs3 = tf.nn.relu(outputs2)
        
        outputs3 = tf.layers.conv2d(outputs3, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv_3', use_bias=False)
        outputs4 = tf.nn.relu(outputs3) 
        
        
        # outputs4 = tf.layers.conv2d(outputs4, 16, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        # outputs5 = tf.nn.relu(outputs4)
        
        outputs4 = patt(outputs4,16,gama3, name='SA3')
        outputs5 = tf.nn.relu(outputs4)
        
        outputs5 = tf.layers.conv2d(outputs5, 16, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
        outputs6 = tf.nn.relu(outputs5)
        
        
        
        outputs6 = tf.layers.conv2d(outputs6, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4', use_bias=False)
        outputs7 = tf.nn.relu(outputs6) 

  
      
        outputs7 = patt(outputs7,32,gama4,name='SA4')
        outputs8 = tf.nn.relu(outputs7)
        
        outputs8 = tf.layers.conv2d(outputs8, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
        # outputs8 = tf.concat([outputs1, outputs8], 3)
        outputs9 = tf.nn.relu(outputs8)
        
        
        outputs9 = tf.layers.conv2d(outputs9, 1, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv6', use_bias=False)
        # outputs10 = tf.nn.relu(inputs + outputs9)
        outputs10 = tf.nn.relu(outputs9)
        
        inputs = tf.clip_by_value(outputs10, 0.0, 1.0)

    return inputs


def sa(inputs, N, gama, name, padding = 'same'):

    n = int(N/4)

    v_in = tf.layers.conv2d(inputs, N, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name, use_bias=False) 
    v_in = tf.nn.relu(v_in)
    
    [c,w,h,x] = np.shape(v_in)
    q_in = conv_1_2(inputs,n,name=name+'_1')
    k_in = conv_1_2(inputs,n,name=name+'_2')
    # q_in = v_in
    # k_in = q_in
    M = int(w*h)
    print(np.shape(k_in))
    print(M)

    k_ = tf.reshape(k_in,[32,M,n])
    q_ = tf.reshape(q_in,[32,M,n])
    pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
    pcm = tf.nn.softmax(pcm)
    v_ = tf.reshape(v_in,[32,M,x])
    att = tf.matmul(pcm, v_)
    att = tf.reshape(att,[c,w,h,x])
    att_out = gama*att + v_in
    return att_out

def sa_t(inputs, N, gama, name, padding = 'same'):

    n = int(N/4)

    v_in = tf.layers.conv2d(inputs, N, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name=name, use_bias=False) 
    v_in = tf.nn.relu(v_in)
    
    [c,w,h,x] = np.shape(v_in)
    q_in = conv_1_2(inputs,n,name=name+'_1')
    k_in = conv_1_2(inputs,n,name=name+'_2')
    # q_in = v_in
    # k_in = q_in
    M = int(w*h)
    print(np.shape(k_in))
    print(M)

    k_ = tf.reshape(k_in,[1,M,n])
    q_ = tf.reshape(q_in,[1,M,n])
    pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
    pcm = tf.nn.softmax(pcm)
    v_ = tf.reshape(v_in,[1,M,x])
    att = tf.matmul(pcm, v_)
    att = tf.reshape(att,[c,w,h,x])
    att_out = gama*att + v_in
    return att_out

def SACNN(inputs, padding = 'same'):
    '''
    MAP-NN 

    inputs: N x input_width x input_height x 1
    
    '''
    
    gama2 = tf.Variable(0.0001,trainable=True, name='conv2_gama')
    gama3 = tf.Variable(0.0001,trainable=True, name='conv3_gama')    
    gama4 = tf.Variable(0.0001,trainable=True, name='conv4_gama')
    
 
    outputs1 = tf.layers.conv2d(inputs, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False) 
    outputs2 = tf.nn.relu(outputs1)
    
    outputs2 = tf.layers.conv2d(outputs2, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2', use_bias=False)
    outputs3 = tf.nn.relu(outputs2) 

    outputs3 = sa(outputs3,32,gama2,name='SA2')
    outputs4 = tf.nn.relu(outputs3)
    # outputs3 = tf.layers.conv2d(outputs3, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
    # outputs4 = tf.nn.relu(outputs3)
    
    outputs4 = tf.layers.conv2d(outputs4, 16, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
    outputs5 = tf.nn.relu(outputs4)
    
    
    outputs5 = sa(outputs5,16,gama3,name='SA3')
    outputs6 = tf.nn.relu(outputs5)
    

    outputs6 = tf.layers.conv2d(outputs6, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4', use_bias=False)
    outputs7 = tf.nn.relu(outputs6)

  
    outputs7 = sa(outputs7,32,gama4,name='SA4')
    outputs8 = tf.nn.relu(outputs7)

    
    outputs8 = tf.layers.conv2d(outputs8, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
    outputs9 = tf.nn.relu(outputs8)
    
    
    outputs9 = tf.layers.conv2d(outputs9, 1, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv6', use_bias=False)
    outputs10 = tf.nn.relu(outputs9)
    
    output = tf.clip_by_value(outputs10, 0.0, 1.0)

    return output


def SACNN_t(inputs, padding = 'same'):
    '''
    MAP-NN 

    inputs: N x input_width x input_height x 1
    
    '''
    
    gama2 = tf.Variable(0.0001,trainable=True, name='conv2_gama')
    gama3 = tf.Variable(0.0001,trainable=True, name='conv3_gama')    
    gama4 = tf.Variable(0.0001,trainable=True, name='conv4_gama')
    
 
    outputs1 = tf.layers.conv2d(inputs, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1', use_bias=False) 
    outputs2 = tf.nn.relu(outputs1)
    
    outputs2 = tf.layers.conv2d(outputs2, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2', use_bias=False)
    outputs3 = tf.nn.relu(outputs2) 

    outputs3 = sa_t(outputs3,32,gama2,name='SA2')
    outputs4 = tf.nn.relu(outputs3)
    # outputs3 = tf.layers.conv2d(outputs3, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
    # outputs4 = tf.nn.relu(outputs3)
    
    outputs4 = tf.layers.conv2d(outputs4, 16, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3', use_bias=False)
    outputs5 = tf.nn.relu(outputs4)
    
    
    outputs5 = sa_t(outputs5,16,gama3,name='SA3')
    outputs6 = tf.nn.relu(outputs5)
    

    outputs6 = tf.layers.conv2d(outputs6, 32, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4', use_bias=False)
    outputs7 = tf.nn.relu(outputs6)

  
    outputs7 = sa_t(outputs7,32,gama4,name='SA4')
    outputs8 = tf.nn.relu(outputs7)

    
    outputs8 = tf.layers.conv2d(outputs8, 64, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5', use_bias=False)
    outputs9 = tf.nn.relu(outputs8)
    
    
    outputs9 = tf.layers.conv2d(outputs9, 1, 3, padding=padding, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv6', use_bias=False)
    outputs10 = tf.nn.relu(outputs9)
    
    output = tf.clip_by_value(outputs10, 0.0, 1.0)

    return output

class mapnn():
    def __init__(self, per_path='MAP_NN32.npy'):
        self.data_dict = np.load(per_path, encoding='latin1').item()
        print("npy file loaded")

        self.var_dict = {}
#        self.trainable = trainable
#        self.dropout = dropout
        
        
        
    def conv_layer(self, bottom, in_channels, out_channels, name):
        with tf.variable_scope(name):
            filt = self.get_conv_var(3, in_channels, out_channels, name)
    
            conv = tf.nn.conv2d(bottom, filt, [1, 1, 1, 1], padding='SAME')
#            batch_mean, batch_var = tf.nn.moments(conv, [0, 1, 2])
#            bn = tf.nn.batch_normalization(conv, batch_mean, batch_var, 0, 1, 1e-3)
            relu = tf.nn.relu(conv)
            return relu
        
        
        
    def transpose(self, bottom, in_channels, out_channels, name):
        with tf.variable_scope(name):
            filt = self.get_conv_var(1, in_channels, out_channels, name)
    
            conv = tf.nn.conv2d(bottom, filt, [1, 1, 1, 1], padding='SAME')
#            batch_mean, batch_var = tf.nn.moments(conv, [0, 1, 2])
#            bn = tf.nn.batch_normalization(conv, batch_mean, batch_var, 0, 1, 1e-3)
            relu = tf.nn.relu(conv)
            return relu
        
        
    def deconv_layer(self, bottom, in_channels, out_channels, name):
        
#        [a,b,c,d] = tf.shape(bottom)        
        with tf.variable_scope(name):
            filt = self.get_conv_var(3, in_channels, out_channels, name)
            
            deconv = tf.nn.conv2d_transpose(bottom, filt, strides=[1, 1, 1, 1], output_shape=[1,128,128,in_channels],padding='SAME')            
            return deconv
        

    def deconv(self, bottom, in_channels, out_channels, name):
        
#        [a,b,c,d] = tf.shape(bottom)        
        with tf.variable_scope(name):
            filt = self.get_conv_var(3, in_channels, out_channels, name)
            
            deconv = tf.nn.conv2d_transpose(bottom, filt, strides=[1, 1, 1, 1], output_shape=[1,128,128,in_channels],padding='SAME')            
            return deconv

    def att_t(self, bottom, in_channels, out_channels, name):
        n = int(out_channels/4)
        [c,w,h,x] = np.shape(bottom)
        M = w*h
        
#        gama = tf.constant(value, dtype=tf.float32, name=name+'gama')
        value = self.data_dict[name+'_gama']

        gama = tf.constant(value, dtype=tf.float32)
        
        filt_1 = self.get_conv_var(1, in_channels, n, name = name+'_1_conv/kernel')
        conv_1 = tf.nn.conv2d(bottom, filt_1, [1, 1, 1, 1], padding='SAME')
        k_in = tf.nn.relu(conv_1)
        
#        filt_2 = self.get_conv_var(1, in_channels, n, name = name+'_2_conv/kernel')
#        conv_2 = tf.nn.conv2d(bottom, filt_2, [1, 1, 1, 1], padding='SAME')
#        q_in = tf.nn.relu(conv_2)
        q_in = k_in
        
        v_in = self.conv_layer(bottom, in_channels, out_channels, name = name+'/kernel')
    
    
    
        k_ = tf.reshape(k_in,[1,M,n])
        q_ = tf.reshape(q_in,[1,M,n]) 
        v_ = tf.reshape(v_in,[1,M,x]) 
        pcm = tf.matmul(k_, tf.transpose(q_,perm=[0,2,1]))
        att = tf.nn.softmax(tf.matmul(pcm, v_))
        att = tf.reshape(att,[c,w,h,x])
        out = gama*att + bottom
        return out
    
    
    
    
    
    
    
    
    
    
    def build(self, img):
        
        res = []
        res.append(img)
        
        for _ in range(5):
        
            conv1 = self.conv_layer(img, 1, 32, "generator_model/conv1/kernel")
            conv2 = self.att_t(conv1, 32, 32, "generator_model/conv2")
            conv3 = self.conv_layer(conv2, 32, 32, "generator_model/conv3/kernel")
            conv4 = self.att_t(conv3, 32, 32, "generator_model/conv4")
            
            deconv5 = self.deconv_layer(conv4, 32, 32, "generator_model/deconv5/kernel")
#            deconv5 = tf.concat([conv4, deconv5], 3)
            deconv5 = conv4 + deconv5
            deconv5 = tf.nn.relu(deconv5)
            
            tran1 = self.transpose(deconv5, 32, 32, "generator_model/transpose1/kernel")
            
            deconv6 = self.deconv_layer(tran1, 32, 32, "generator_model/deconv6/kernel")
#            deconv6 = tf.concat([conv3, deconv6], 3)
            deconv6 = conv3 + deconv6
            deconv6 = tf.nn.relu(deconv6)
            
            tran2 = self.transpose(deconv5, 32, 32, "generator_model/transpose2/kernel")
            
            deconv7 = self.deconv_layer(tran2, 32, 32, "generator_model/deconv7/kernel")
#            deconv7 = tf.concat([conv2, deconv7], 3)
            deconv7 = conv2 + deconv7
            deconv7 = tf.nn.relu(deconv7)
            
            tran3 = self.transpose(deconv7, 32, 32, "generator_model/transpose3/kernel")
    
            deconv8 = self.deconv(tran3, 1, 32, "generator_model/deconv8/kernel")
            deconv8 = tf.nn.relu(deconv8 + img)
            
            
            
            out = tf.clip_by_value(deconv8, 0.0, 1.0)
            res.append(out)

        return res
        
    def max_pool(self, bottom):
        return tf.nn.max_pool(bottom, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
    
    def get_conv_var(self, filter_size, in_channels, out_channels, name):
        initial_value = tf.truncated_normal([filter_size, filter_size, in_channels, out_channels], 0.0, 0.001)
        filters = self.get_var(initial_value, name,name + "_filters")
        return filters

    def get_var(self, initial_value, name, var_name):
#        if self.data_dict is not None and name in self.data_dict:
        value = self.data_dict[name]

        var = tf.constant(value, dtype=tf.float32, name=var_name)

        self.var_dict[(name)] = var

        # print var_name, var.get_shape().as_list()
        assert var.get_shape() == initial_value.get_shape()

        return var








def leaky_relu(inputs, alpha):
    return 0.5 * (1 + alpha) * inputs + 0.5 * (1-alpha) * tf.abs(inputs)     


def discriminator_model(inputs):

    outputs = tf.layers.conv2d(inputs, 64, 3, padding='same', kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv1')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.conv2d(outputs, 64, 3, padding='same', strides=(2,2), kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv2')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.conv2d(outputs, 128, 3, padding='same', kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv3')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.conv2d(outputs, 128, 3, padding='same', strides=(2,2), kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv4')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.conv2d(outputs, 256, 3, padding='same', kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv5')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.conv2d(outputs, 256, 3, padding='same', strides=(2,2), kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv6')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.dense(outputs, units=1024, name='dense1')
    outputs = leaky_relu(outputs, alpha=0.2)

    outputs = tf.layers.dense(outputs, units=1, name='dense2')

    return outputs
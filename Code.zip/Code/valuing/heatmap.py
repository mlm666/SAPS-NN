# -*- coding: utf-8 -*-
"""
Created on Tue Dec  7 23:33:46 2021

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Sep 14 18:39:19 2021

@author: Administrator
"""

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import seaborn as sns

def norm(x):
    x = abs(x)
#    high = 0.5
#    low = 0
#    x = (x - low) / (high - low)
#    x[x<0.0] = 0.0
#    x[x>1.0] = 1.0
    return x


roi_data = []
img_data = []
dif_data = []
#heat_data = []

fig = "1_051.npy"

LD_path = 'PETtest/75npy/' + fig # LDCT image
HD_path = 'PETtest/150npy/' + fig 
path_cpce = "./result_neu/CPCE/npy/" + fig
path_wgan = "./result_neu/WGAN/npy/" + fig
path_sacnn = "./result_neu/SACNN/npy/" + fig
path_dncnn = "./result_neu/DNCNN/npy/" + fig
path_map = "./result_neu/MAP-NN/npy/" + fig
path_red = "./result_neu/REDCNN/npy/" + fig
path_sama = "./result_neu/SAMA-NN-4/npy/" + fig

sama = np.load(path_sama)
LD = np.load(LD_path)
HD = np.load(HD_path)
cpce = np.load(path_cpce)
wgan = np.load(path_wgan)
red = np.load(path_red)
mapnn = np.load(path_map)
dn = np.load(path_dncnn)
sa = np.load(path_sacnn)




r = cv2.selectROI("ROI", sama, False)

#blank = np.zeros([r[3], r[2]])

img_data.append(LD)
img_data.append(HD)
img_data.append(sama)
img_data.append(cpce)
img_data.append(wgan)
img_data.append(red)
img_data.append(sa)
#roi_data.append(dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
img_data.append(dn)


roi_data.append(LD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(cpce[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(wgan[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(red[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(sa[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(sama[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])



dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - LD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - cpce[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - wgan[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - red[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - sa[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - sama[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])



LD_MSE = np.mean(dif_data[0]*dif_data[0])
cpce_MSE = np.mean(dif_data[1]*dif_data[1])
wgan_MSE = np.mean(dif_data[2]*dif_data[2])
red_MSE = np.mean(dif_data[3]*dif_data[3])
sa_MSE = np.mean(dif_data[4]*dif_data[4])
dn_MSE = np.mean(dif_data[5]*dif_data[5])
sama_MSE = np.mean(dif_data[6]*dif_data[6])




    
for i in range(7):
    heat_data = sns.heatmap(norm(dif_data[i]), vmax = 0.5, vmin = 0.0, cmap = 'rainbow', cbar = False, square = True)
    plt.savefig('./heatmap_{}.pdf'.format(i), bbox_inches = 'tight', pad_inches=0.1)   

heat_data = sns.heatmap(norm(dif_data[0]), vmax = 0.5, vmin = 0.0, cmap = 'rainbow', square = True)
plt.savefig('./heatmap_ref.pdf'.format(i), bbox_inches = 'tight', pad_inches=0.1)   



with open("ROI_mse.txt","a")as t:
    t.write("Image number: %s --- ROI range: %d - %d ;  %d - %d \n"%(fig, r[1], r[1]+r[3], r[0], r[0]+r[2]))
    t.write("LD_MSE:%6f - cpce_MSE:%6f - wgan_MSE:%6f - red_MSE:%6f - sa_MSE:%6f - dn_MSE:%6f - sama_MSE:%6f \n\n\n"%(LD_MSE, cpce_MSE, wgan_MSE, red_MSE, sa_MSE, dn_MSE, sama_MSE))
t.close()
#dif = HD-sama
#dif_data = sns.heatmap(dif)
#plt.savefig('./sama-heatmap.pdf', bbox_inches = 'tight', pad_inches=0.1)  
#plt.imshow(dif_data)
#ax = dif_data[1]
#plt.show()


#figure = ax.get_figure()
#figure.savefig('sns_heatmap.jpg')    
#fig_titles = ['LDPET', 'SAMA-NN', 'CPCE', 'WGAN','RED-CNN', 'SACNN', 'DNCNN']
#f, axs = plt.subplots(figsize=(40, 40),nrows=2, ncols=4)
#for i, img in enumerate(dif_data):
#    if i<4:
#        axs[0,i].imshow(img)
#        axs[0,i].set_title(fig_titles[i], fontsize=30)
#        axs[0,i].axis('off') 
#    else:
#        axs[1,i-4].imshow(img)
#        axs[1,i-4].set_title(fig_titles[i], fontsize=30)  
#        axs[1,i-4].axis('off')    
        
#plt.savefig('./result_neu/ROI/dif_{}.pdf'.format(fig), bbox_inches = 'tight', pad_inches=0.1)    
       
    
    
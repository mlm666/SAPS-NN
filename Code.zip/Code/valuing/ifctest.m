clear;
clc;
LDFolder=fullfile('F:\PROGRAM\MATLAB2016B\bin\SACNN');
LDdir=dir(fullfile(LDFolder,'*.mat'));

HDFolder=fullfile('F:\PROGRAM\MATLAB2016B\bin\150mat');
HDdir=dir(fullfile(HDFolder,'*.mat'));

len = length(LDdir);
ifc=[];
adv=0;
for i = 1:len
    LD_file_name{i}=LDdir(i).name;
    ld=cell2mat(struct2cell(load(fullfile(LDFolder,LD_file_name{i}))));
    
    HD_file_name{i}=HDdir(i).name;
    hd=cell2mat(struct2cell(load(fullfile(HDFolder,HD_file_name{i}))));    
    re=ifcvec(ld,hd);
    ifc(i)=re;
    adv=adv+re;
    fin=adv/len;
    
end
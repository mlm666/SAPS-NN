# -*- coding: utf-8 -*-
"""
Created on Tue Sep 14 18:39:19 2021

@author: Administrator
"""

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import seaborn as sns


roi_data = []
img_data = []
dif_data = []
r = []

fig = "1_051.npy"

LD_path = 'PETtest/75npy/' + fig # LDCT image
HD_path = 'PETtest/150npy/' + fig 
path_cpce = "./result_neu/CPCE/npy/" + fig
path_wgan = "./result_neu/WGAN/npy/" + fig
path_sacnn = "./result_neu/SACNN/npy/" + fig
path_dncnn = "./result_neu/DNCNN/npy/" + fig
path_map = "./result_neu/MAP-NN/npy/" + fig
path_red = "./result_neu/REDCNN/npy/" + fig
path_sama = "./result_neu/SAMA-NN-4/npy/" + fig

sama = np.load(path_sama)
LD = np.load(LD_path)
HD = np.load(HD_path)
cpce = np.load(path_cpce)
wgan = np.load(path_wgan)
red = np.load(path_red)
mapnn = np.load(path_map)
dn = np.load(path_dncnn)
sa = np.load(path_sacnn)
#
#r[0] = 47
#r[1] = 68
#r[2] = 89
#r[3] = 107
r.append(42)
r.append(65)
r.append(93)
r.append(113)
#r = cv2.selectROI("ROI", sama, False)

#blank = np.zeros([r[3], r[2]])

img_data.append(LD)
img_data.append(HD)
img_data.append(sama)
img_data.append(cpce)
img_data.append(wgan)
img_data.append(red)
img_data.append(sa)
#roi_data.append(dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
img_data.append(dn)


roi_data.append(LD[r[1]:r[3], r[0]:r[2]])
roi_data.append(HD[r[1]:r[3], r[0]:r[2]])
roi_data.append(sama[r[1]:r[3], r[0]:r[2]])
roi_data.append(cpce[r[1]:r[3], r[0]:r[2]])
roi_data.append(wgan[r[1]:r[3], r[0]:r[2]])
roi_data.append(red[r[1]:r[3], r[0]:r[2]])
roi_data.append(sa[r[1]:r[3], r[0]:r[2]])
#roi_data.append(dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
roi_data.append(dn[r[1]:r[3], r[0]:r[2]])
#roi_data.append(blank)

#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - LD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - sama[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - cpce[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - wgan[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - red[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - sa[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])
#dif_data.append(HD[r[1]:r[1]+r[3], r[0]:r[0]+r[2]] - dn[r[1]:r[1]+r[3], r[0]:r[0]+r[2]])

#
fig_titles = ['LDPET', 'HDPET', 'SAMA-NN', 'CPCE', 'WGAN','RED-CNN', 'SACNN', 'DNCNN']
f, axs = plt.subplots(figsize=(40, 40),nrows=2, ncols=4)

for i, img in enumerate(roi_data):
    if i<4:
        axs[0,i].imshow(img, cmap=plt.cm.gray)
        axs[0,i].set_title(fig_titles[i], fontsize=30)
        axs[0,i].axis('off') 
    else:
        axs[1,i-4].imshow(img, cmap=plt.cm.gray)
        axs[1,i-4].set_title(fig_titles[i], fontsize=30)  
        axs[1,i-4].axis('off')
plt.savefig('./result_neu/ROI/ROI_{}.pdf'.format(fig), bbox_inches = 'tight', pad_inches=0.1)
    

    
fig_titles = ['LDPET', 'HDPET', 'SAMA-NN', 'CPCE', 'WGAN','RED-CNN', 'SACNN', 'DNCNN']
f, axs = plt.subplots(figsize=(40, 40),nrows=2, ncols=4)
for i, img in enumerate(img_data):
    if i<4:
        axs[0,i].imshow(img, cmap=plt.cm.gray)
        axs[0,i].set_title(fig_titles[i], fontsize=30)
        axs[0,i].axis('off') 
    else:
        axs[1,i-4].imshow(img, cmap=plt.cm.gray)
        axs[1,i-4].set_title(fig_titles[i], fontsize=30)  
        axs[1,i-4].axis('off')
plt.savefig('./result_neu/ROI/img_{}.pdf'.format(fig), bbox_inches = 'tight', pad_inches=0.1)    
    
#for i in range(7):
#    dif_data[i] = sns.heatmap(dif_data[i])


ax = np.zeros_like(sama)
for j in (r[0],r[2]):
    for i in (r[1], r[3]):
        ax[i,j] = 1

plt.imsave('./result_neu/ROI/ROI_IMAGE_{}.jpg'.format(fig[0:5]), ax)        
#plt.show()
#figure = ax.get_figure()
#figure.savefig('/result_neu/ROI/ROI_IMAGE_{}.jpg'.format(fig))    
#fig_titles = ['LDPET', 'SAMA-NN', 'CPCE', 'WGAN','RED-CNN', 'SACNN', 'DNCNN']
#f, axs = plt.subplots(figsize=(40, 40),nrows=2, ncols=4)
#for i, img in enumerate(dif_data):
#    if i<4:
#        axs[0,i].imshow(img)
#        axs[0,i].set_title(fig_titles[i], fontsize=30)
#        axs[0,i].axis('off') 
#    else:
#        axs[1,i-4].imshow(img)
#        axs[1,i-4].set_title(fig_titles[i], fontsize=30)  
#        axs[1,i-4].axis('off')    
        
#plt.savefig('./result_neu/ROI/dif_{}.pdf'.format(fig), bbox_inches = 'tight', pad_inches=0.1)    
       
    
    